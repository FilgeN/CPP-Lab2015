//lab04.h

#include "Variable.h"

#ifndef _LAB_04_H_
#define _LAB_04_H_





#endif
